import React from 'react';
import { Link } from 'react-router-dom';
import {  as Facebook,  as Twitter,  as Instagram,  as Youtube,  as Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-indigo-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">BasketPro</h3>
            <p className="text-indigo-200 mb-4">
              Your ultimate destination for basketball news, teams, players, and events.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-indigo-200 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-indigo-200 hover:text-white">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-indigo-200 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-indigo-200 hover:text-white">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-indigo-200 hover:text-white">Home</Link>
              </li>
              <li>
                <Link to="/teams" className="text-indigo-200 hover:text-white">Teams</Link>
              </li>
              <li>
                <Link to="/players" className="text-indigo-200 hover:text-white">Players</Link>
              </li>
              <li>
                <Link to="/events" className="text-indigo-200 hover:text-white">Events</Link>
              </li>
              <li>
                <Link to="/news" className="text-indigo-200 hover:text-white">News</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-indigo-200 hover:text-white">About Us</Link>
              </li>
              <li>
                <Link to="/privacy" className="text-indigo-200 hover:text-white">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/terms" className="text-indigo-200 hover:text-white">Terms of Service</Link>
              </li>
              <li>
                <Link to="/faq" className="text-indigo-200 hover:text-white">FAQ</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <p className="flex items-center text-indigo-200 mb-2">
              <Mail className="h-5 w-5 mr-2" />
              info@basketpro.com
            </p>
            <Link 
              to="/contact" 
              className="inline-block bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-2 px-4 rounded-md mt-2"
            >
              Send Message
            </Link>
          </div>
        </div>
        
        <div className="border-t border-indigo-800 mt-8 pt-8 text-center text-indigo-300">
          <p>&copy; {new Date().getFullYear()} BasketPro. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;