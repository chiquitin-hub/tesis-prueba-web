import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Player } from '../types';
import {  as Search,  as User } from 'lucide-react';

const Players: React.FC = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [positionFilter, setPositionFilter] = useState('');

  useEffect(() => {
    const fetchPlayers = async () => {
      try {
        const { data, error } = await supabase
          .from('players')
          .select('*')
          .order('name');

        if (error) {
          throw error;
        }

        setPlayers(data || []);
      } catch (error) {
        console.error('Error fetching players:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPlayers();
  }, []);

  // Sample players data for initial display
  const samplePlayers: Player[] = [
    {
      id: 1,
      name: 'LeBron James',
      position: 'Forward',
      team_id: 1,
      image_url: 'https://images.unsplash.com/photo-1546519638-68e109acd27d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      stats: {
        points_per_game: 27.4,
        rebounds_per_game: 8.5,
        assists_per_game: 8.3,
        steals_per_game: 1.6,
        blocks_per_game: 0.6
      },
      created_at: new Date().toISOString()
    },
    {
      id: 2,
      name: 'Stephen Curry',
      position: 'Guard',
      team_id: 3,
      image_url: 'https://images.unsplash.com/photo-1518063319789-7217e6706b04?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      stats: {
        points_per_game: 30.1,
        rebounds_per_game: 5.5,
        assists_per_game: 6.1,
        steals_per_game: 1.3,
        blocks_per_game: 0.1
      },
      created_at: new Date().toISOString()
    },
    {
      id: 3,
      name: 'Giannis Antetokounmpo',
      position: 'Forward',
      team_id: 5,
      image_url: 'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      stats: {
        points_per_game: 29.9,
        rebounds_per_game: 11.6,
        assists_per_game: 5.8,
        steals_per_game: 1.0,
        blocks_per_game: 1.2
      },
      created_at: new Date().toISOString()
    },
    {
      id: 4,
      name: 'Kevin Durant',
      position: 'Forward',
      team_id: 2,
      image_url: 'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      stats: {
        points_per_game: 27.2,
        rebounds_per_game: 7.1,
        assists_per_game: 4.3,
        steals_per_game: 0.7,
        blocks_per_game: 1.1
      },
      created_at: new Date().toISOString()
    },
    {
      id: 5,
      name: 'Nikola Jokic',
      position: 'Center',
      team_id: 4,
      image_url: 'https://images.unsplash.com/photo-1504450758481-7338eba7524a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      stats: {
        points_per_game: 26.4,
        rebounds_per_game: 10.8,
        assists_per_game: 8.3,
        steals_per_game: 1.3,
        blocks_per_game: 0.7
      },
      created_at: new Date().toISOString()
    },
    {
      id: 6,
      name: 'Luka Doncic',
      position: 'Guard',
      team_id: 6,
      image_url: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      stats: {
        points_per_game: 28.4,
        rebounds_per_game: 9.1,
        assists_per_game: 8.7,
        steals_per_game: 1.1,
        blocks_per_game: 0.5
      },
      created_at: new Date().toISOString()
    },
  ];

  const displayPlayers = players.length > 0 ? players : samplePlayers;
  
  const filteredPlayers = displayPlayers.filter(player => {
    const matchesSearch = player.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPosition = positionFilter === '' || player.position === positionFilter;
    return matchesSearch && matchesPosition;
  });

  const positions = ['Guard', 'Forward', 'Center'];

  return (
    <div className="min-h-screen bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Basketball Players</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover detailed profiles and statistics of basketball players from around the world.
          </p>
        </div>

        {/* Search and Filter */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                placeholder="Search players..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="w-full md:w-48">
              <select
                className="block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                value={positionFilter}
                onChange={(e) => setPositionFilter(e.target.value)}
              >
                <option value="">All Positions</option>
                {positions.map((position) => (
                  <option key={position} value={position}>
                    {position}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPlayers.map((player) => (
              <div key={player.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src={player.image_url}
                  alt={player.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex items-center mb-2">
                    <User className="h-5 w-5 text-indigo-600 mr-2" />
                    <h2 className="text-xl font-semibold text-gray-900">{player.name}</h2>
                  </div>
                  <p className="text-gray-600 mb-1">Position: {player.position}</p>
                  <div className="mt-4 grid grid-cols-3 gap-2 text-sm mb-4">
                    <div className="text-center">
                      <span className="block font-semibold text-indigo-600">{player.stats.points_per_game}</span>
                      <span className="text-gray-500">PPG</span>
                    </div>
                    <div className="text-center">
                      <span className="block font-semibold text-indigo-600">{player.stats.rebounds_per_game}</span>
                      <span className="text-gray-500">RPG</span>
                    </div>
                    <div className="text-center">
                      <span className="block font-semibold text-indigo-600">{player.stats.assists_per_game}</span>
                      <span className="text-gray-500">APG</span>
                    </div>
                  </div>
                  <Link
                    to={`/players/${player.id}`}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    View Profile
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Players;