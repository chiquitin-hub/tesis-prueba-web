import React from 'react';
import { Link } from 'react-router-dom';
import {  as Calendar,  as Users,  as Award,  as TrendingUp } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div 
        className="bg-indigo-900 text-white py-20"
        style={{
          backgroundImage: 'linear-gradient(rgba(49, 46, 129, 0.8), rgba(49, 46, 129, 0.8)), url("https://images.unsplash.com/photo-1546519638-68e109acd27d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Welcome to BasketPro</h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              Your ultimate destination for basketball news, teams, players, and events.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/register"
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 px-6 rounded-lg text-lg transition duration-300"
              >
                Join Now
              </Link>
              <Link
                to="/events"
                className="bg-white hover:bg-gray-100 text-indigo-900 font-bold py-3 px-6 rounded-lg text-lg transition duration-300"
              >
                Upcoming Events
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">What We Offer</h2>
            <p className="mt-4 text-xl text-gray-600">
              Everything you need to stay connected with the basketball world
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 mb-4 bg-indigo-100 rounded-full text-indigo-600">
                <Users className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Team Profiles</h3>
              <p className="text-gray-600">
                Detailed information about your favorite basketball teams.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 mb-4 bg-indigo-100 rounded-full text-indigo-600">
                <Award className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Player Stats</h3>
              <p className="text-gray-600">
                Comprehensive statistics and profiles of basketball players.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 mb-4 bg-indigo-100 rounded-full text-indigo-600">
                <Calendar className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Events Calendar</h3>
              <p className="text-gray-600">
                Stay updated with upcoming basketball events and games.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 mb-4 bg-indigo-100 rounded-full text-indigo-600">
                <TrendingUp className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Latest News</h3>
              <p className="text-gray-600">
                Breaking news and updates from the basketball world.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Content */}
      <div className="py-16 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Featured Content</h2>
            <p className="mt-4 text-xl text-gray-600">
              Check out our latest highlights and featured content
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                alt="Basketball game" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Championship Finals</h3>
                <p className="text-gray-600 mb-4">
                  Recap of the thrilling championship finals and key moments.
                </p>
                <Link
                  to="/news/championship-finals"
                  className="text-indigo-600 hover:text-indigo-800 font-medium"
                >
                  Read More →
                </Link>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1518063319789-7217e6706b04?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                alt="Basketball player" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Rising Stars</h3>
                <p className="text-gray-600 mb-4">
                  Meet the emerging talents who are making waves in basketball.
                </p>
                <Link
                  to="/players/rising-stars"
                  className="text-indigo-600 hover:text-indigo-800 font-medium"
                >
                  Read More →
                </Link>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1504450758481-7338eba7524a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                alt="Basketball court" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Training Techniques</h3>
                <p className="text-gray-600 mb-4">
                  Expert tips and techniques to improve your basketball skills.
                </p>
                <Link
                  to="/news/training-techniques"
                  className="text-indigo-600 hover:text-indigo-800 font-medium"
                >
                  Read More →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div 
        className="py-16 bg-indigo-900 text-white"
        style={{
          backgroundImage: 'linear-gradient(rgba(49, 46, 129, 0.9), rgba(49, 46, 129, 0.9)), url("https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Basketball Community</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Sign up today to get exclusive access to content, events, and connect with other basketball enthusiasts.
          </p>
          <Link
            to="/register"
            className="bg-white hover:bg-gray-100 text-indigo-900 font-bold py-3 px-8 rounded-lg text-lg transition duration-300"
          >
            Sign Up Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;