import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Team } from '../types';
import {  as Search,  as Users } from 'lucide-react';

const Teams: React.FC = () => {
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchTeams = async () => {
      try {
        const { data, error } = await supabase
          .from('teams')
          .select('*')
          .order('name');

        if (error) {
          throw error;
        }

        setTeams(data || []);
      } catch (error) {
        console.error('Error fetching teams:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTeams();
  }, []);

  const filteredTeams = teams.filter(team =>
    team.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sample teams data for initial display
  const sampleTeams: Team[] = [
    {
      id: 1,
      name: 'Los Angeles Lakers',
      logo_url: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      description: 'One of the most successful teams in NBA history with a rich legacy of championships.',
      created_at: new Date().toISOString()
    },
    {
      id: 2,
      name: 'Chicago Bulls',
      logo_url: 'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      description: 'Famous for their dominance in the 1990s with Michael Jordan leading the team.',
      created_at: new Date().toISOString()
    },
    {
      id: 3,
      name: 'Golden State Warriors',
      logo_url: 'https://images.unsplash.com/photo-1504450758481-7338eba7524a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      description: 'Known for their revolutionary small-ball approach and three-point shooting prowess.',
      created_at: new Date().toISOString()
    },
    {
      id: 4,
      name: 'Boston Celtics',
      logo_url: 'https://images.unsplash.com/photo-1518063319789-7217e6706b04?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      description: 'Historic franchise with the most NBA championships in league history.',
      created_at: new Date().toISOString()
    },
    {
      id: 5,
      name: 'Miami Heat',
      logo_url: 'https://images.unsplash.com/photo-1546519638-68e109acd27d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      description: 'Known for their "Heat Culture" emphasizing hard work, discipline, and conditioning.',
      created_at: new Date().toISOString()
    },
    {
      id: 6,
      name: 'Toronto Raptors',
      logo_url: 'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      description: 'The only NBA team based in Canada, 2019 NBA champions.',
      created_at: new Date().toISOString()
    },
  ];

  const displayTeams = teams.length > 0 ? filteredTeams : sampleTeams;

  return (
    <div className="min-h-screen bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Basketball Teams</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore detailed profiles of basketball teams from around the world.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-xl mx-auto mb-8">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              placeholder="Search teams..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {displayTeams.map((team) => (
              <div key={team.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src={team.logo_url}
                  alt={team.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex items-center mb-2">
                    <Users className="h-5 w-5 text-indigo-600 mr-2" />
                    <h2 className="text-xl font-semibold text-gray-900">{team.name}</h2>
                  </div>
                  <p className="text-gray-600 mb-4 line-clamp-2">{team.description}</p>
                  <Link
                    to={`/teams/${team.id}`}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    View Team
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Teams;