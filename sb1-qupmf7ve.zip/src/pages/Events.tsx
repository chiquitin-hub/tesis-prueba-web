import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Event } from '../types';
import {  as Calendar,  as MapPin,  as Clock,  as Search } from 'lucide-react';

const Events: React.FC = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const { data, error } = await supabase
          .from('events')
          .select('*')
          .order('date');

        if (error) {
          throw error;
        }

        setEvents(data || []);
      } catch (error) {
        console.error('Error fetching events:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  // Sample events data for initial display
  const sampleEvents: Event[] = [
    {
      id: 1,
      title: 'NBA All-Star Weekend',
      description: 'Annual exhibition event featuring the league\'s best players competing in various competitions.',
      location: 'Chicago, IL',
      date: '2025-02-15',
      image_url: 'https://images.unsplash.com/photo-1504450758481-7338eba7524a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      created_at: new Date().toISOString()
    },
    {
      id: 2,
      title: 'FIBA World Cup',
      description: 'International basketball competition featuring national teams from around the world.',
      location: 'Madrid, Spain',
      date: '2025-08-25',
      image_url: 'https://images.unsplash.com/photo-1518063319789-7217e6706b04?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      created_at: new Date().toISOString()
    },
    {
      id: 3,
      title: 'NBA Finals',
      description: 'Championship series of the National Basketball Association (NBA) played between the Eastern and Western Conference champions.',
      location: 'Los Angeles, CA',
      date: '2025-06-10',
      image_url: 'https://images.unsplash.com/photo-1546519638-68e109acd27d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      created_at: new Date().toISOString()
    },
    {
      id: 4,
      title: 'Basketball Youth Camp',
      description: 'Training camp for young basketball players to develop their skills and learn from professionals.',
      location: 'Miami, FL',
      date: '2025-07-05',
      image_url: 'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      created_at: new Date().toISOString()
    },
    {
      id: 5,
      title: 'Charity Basketball Tournament',
      description: 'Basketball tournament raising funds for local community programs and charities.',
      location: 'New York, NY',
      date: '2025-04-18',
      image_url: 'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      created_at: new Date().toISOString()
    },
    {
      id: 6,
      title: 'College Basketball Championship',
      description: 'Annual college basketball tournament featuring the top teams in the country.',
      location: 'Indianapolis, IN',
      date: '2025-03-30',
      image_url: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      created_at: new Date().toISOString()
    }
  ];

  const displayEvents = events.length > 0 ? events : sampleEvents;
  
  const filteredEvents = displayEvents.filter(event =>
    event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="min-h-screen bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Basketball Events</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Stay updated with upcoming basketball events, tournaments, and games.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-xl mx-auto mb-8">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              placeholder="Search events by title or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredEvents.map((event) => (
              <div key={event.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src={event.image_url}
                  alt={event.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">{event.title}</h2>
                  <p className="text-gray-600 mb-4 line-clamp-2">{event.description}</p>
                  
                  <div className="flex items-center text-gray-500 mb-2">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{formatDate(event.date)}</span>
                  </div>
                  
                  <div className="flex items-center text-gray-500 mb-4">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>{event.location}</span>
                  </div>
                  
                  <Link
                    to={`/events/${event.id}`}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Events;