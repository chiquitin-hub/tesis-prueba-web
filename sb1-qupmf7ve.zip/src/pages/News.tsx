import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import {  as Search,  as Calendar } from 'lucide-react';

interface NewsArticle {
  id: number;
  title: string;
  content: string;
  image_url: string;
  author: string;
  published_date: string;
  category: string;
  created_at: string;
}

const News: React.FC = () => {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const { data, error } = await supabase
          .from('news')
          .select('*')
          .order('published_date', { ascending: false });

        if (error) {
          throw error;
        }

        setArticles(data || []);
      } catch (error) {
        console.error('Error fetching news articles:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchArticles();
  }, []);

  // Sample news data for initial display
  const sampleArticles: NewsArticle[] = [
    {
      id: 1,
      title: 'Championship Finals Recap: An Epic Battle to the End',
      content: 'The championship finals delivered an unforgettable series of games that kept fans on the edge of their seats until the final buzzer.',
      image_url: 'https://images.unsplash.com/photo-1519861531473-9200262188bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      author: 'Michael Johnson',
      published_date: '2025-06-20',
      category: 'Game Recap',
      created_at: new Date().toISOString()
    },
    {
      id: 2,
      title: 'Rising Stars: The Next Generation of Basketball Talent',
      content: 'Meet the emerging talents who are making waves in basketball and poised to become the next superstars of the sport.',
      image_url: 'https://images.unsplash.com/photo-1518063319789-7217e6706b04?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      author: 'Sarah Williams',
      published_date: '2025-05-15',
      category: 'Player Spotlight',
      created_at: new Date().toISOString()
    },
    {
      id: 3,
      title: 'Advanced Training Techniques for Basketball Players',
      content: 'Expert tips and techniques to improve your basketball skills, from shooting form to defensive strategies.',
      image_url: 'https://images.unsplash.com/photo-1504450758481-7338eba7524a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      author: 'David Thompson',
      published_date: '2025-04-28',
      category: 'Training',
      created_at: new Date().toISOString()
    },
    {
      id: 4,
      title: 'Major Trade Shakes Up League: Star Player Changes Teams',
      content: 'A blockbuster trade has sent shockwaves through the basketball world as a star player moves to a new team.',
      image_url: 'https://images.unsplash.com/photo-1546519638-68e109acd27d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      author: 'Jennifer Davis',
      published_date: '2025-03-10',
      category: 'Transfers',
      created_at: new Date().toISOString()
    },
    {
      id: 5,
      title: 'Basketball Analytics: How Data is Changing the Game',
      content: 'An in-depth look at how advanced analytics and statistics are revolutionizing basketball strategy and player evaluation.',
      image_url: 'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      author: 'Robert Chen',
      published_date: '2025-02-22',
      category: 'Analytics',
      created_at: new Date().toISOString()
    },
    {
      id: 6,
      title: 'Basketball and Mental Health: Players Speak Out',
      content: 'Professional basketball players discuss the importance of mental health and share their personal experiences.',
      image_url: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      author: 'Lisa Rodriguez',
      published_date: '2025-01-15',
      category: 'Health',
      created_at: new Date().toISOString()
    }
  ];

  const displayArticles = articles.length > 0 ? articles : sampleArticles;
  
  const filteredArticles = displayArticles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          article.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === '' || article.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const categories = [...new Set(displayArticles.map(article => article.category))];

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="min-h-screen bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Basketball News</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Stay updated with the latest news, articles, and insights from the basketball world.
          </p>
        </div>

        {/* Search and Filter */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                placeholder="Search news..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="w-full md:w-48">
              <select
                className="block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="">All Categories</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map((article) => (
              <div key={article.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img
                  src={article.image_url}
                  alt={article.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                      {article.category}
                    </span>
                    <div className="flex items-center text-gray-500 text-sm">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(article.published_date)}
                    </div>
                  </div>
                  
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">{article.title}</h2>
                  <p className="text-gray-600 mb-4 line-clamp-3">{article.content}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">By {article.author}</span>
                    <Link
                      to={`/news/${article.id}`}
                      className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-medium"
                    >
                      Read More →
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default News;