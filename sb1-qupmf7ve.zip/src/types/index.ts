export interface User {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
  created_at: string;
}

export interface Team {
  id: number;
  name: string;
  logo_url: string;
  description: string;
  created_at: string;
}

export interface Player {
  id: number;
  name: string;
  position: string;
  team_id: number;
  image_url: string;
  stats: PlayerStats;
  created_at: string;
}

export interface PlayerStats {
  points_per_game: number;
  rebounds_per_game: number;
  assists_per_game: number;
  steals_per_game: number;
  blocks_per_game: number;
}

export interface Event {
  id: number;
  title: string;
  description: string;
  location: string;
  date: string;
  image_url: string;
  created_at: string;
}

export interface ContactMessage {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  created_at: string;
}