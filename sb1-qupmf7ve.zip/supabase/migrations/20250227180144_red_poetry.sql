/*
  # Create news table

  1. New Tables
    - `news`
      - `id` (bigint, primary key)
      - `title` (text, not null)
      - `content` (text)
      - `image_url` (text)
      - `author` (text)
      - `published_date` (date)
      - `category` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  2. Security
    - Enable RLS on `news` table
    - Add policy for public read access
    - Add policy for authenticated users with admin role to insert/update/delete
*/

CREATE TABLE IF NOT EXISTS news (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  title text NOT NULL,
  content text,
  image_url text,
  author text,
  published_date date DEFAULT CURRENT_DATE,
  category text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE news ENABLE ROW LEVEL SECURITY;

CREATE POLICY "News articles are viewable by everyone"
  ON news
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "News articles are insertable by authenticated users with admin role"
  ON news
  FOR INSERT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

CREATE POLICY "News articles are updatable by authenticated users with admin role"
  ON news
  FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

CREATE POLICY "News articles are deletable by authenticated users with admin role"
  ON news
  FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));