/*
  # Create players table

  1. New Tables
    - `players`
      - `id` (bigint, primary key)
      - `name` (text, not null)
      - `position` (text)
      - `team_id` (bigint, references teams)
      - `image_url` (text)
      - `stats` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  2. Security
    - Enable RLS on `players` table
    - Add policy for public read access
    - Add policy for authenticated users with admin role to insert/update/delete
*/

CREATE TABLE IF NOT EXISTS players (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  name text NOT NULL,
  position text,
  team_id bigint REFERENCES teams,
  image_url text,
  stats jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE players ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Players are viewable by everyone"
  ON players
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Players are insertable by authenticated users with admin role"
  ON players
  FOR INSERT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

CREATE POLICY "Players are updatable by authenticated users with admin role"
  ON players
  FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

CREATE POLICY "Players are deletable by authenticated users with admin role"
  ON players
  FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));