/*
  # Create contact messages table

  1. New Tables
    - `contact_messages`
      - `id` (bigint, primary key)
      - `name` (text, not null)
      - `email` (text, not null)
      - `subject` (text)
      - `message` (text, not null)
      - `created_at` (timestamptz)
  2. Security
    - Enable RLS on `contact_messages` table
    - Add policy for public to insert messages
    - Add policy for authenticated users with admin role to view messages
*/

CREATE TABLE IF NOT EXISTS contact_messages (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  name text NOT NULL,
  email text NOT NULL,
  subject text,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Contact messages can be inserted by anyone"
  ON contact_messages
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Contact messages are viewable by authenticated users with admin role"
  ON contact_messages
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));