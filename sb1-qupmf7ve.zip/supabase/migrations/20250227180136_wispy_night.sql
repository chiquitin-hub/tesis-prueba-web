/*
  # Create teams table

  1. New Tables
    - `teams`
      - `id` (bigint, primary key)
      - `name` (text, not null)
      - `logo_url` (text)
      - `description` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  2. Security
    - Enable RLS on `teams` table
    - Add policy for public read access
    - Add policy for authenticated users with admin role to insert/update/delete
*/

CREATE TABLE IF NOT EXISTS teams (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  name text NOT NULL,
  logo_url text,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE teams ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Teams are viewable by everyone"
  ON teams
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Teams are insertable by authenticated users with admin role"
  ON teams
  FOR INSERT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

CREATE POLICY "Teams are updatable by authenticated users with admin role"
  ON teams
  FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

CREATE POLICY "Teams are deletable by authenticated users with admin role"
  ON teams
  FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));